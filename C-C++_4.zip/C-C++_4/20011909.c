#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include <locale.h>

#define ALPHABET_SIZE 10
#define MAX_NUMBER_LENGTH 100

typedef struct TrieNode {
    struct TrieNode* children[ALPHABET_SIZE];
    bool isEndOfWord;
} TrieNode;


TrieNode* createNode() {
    TrieNode* node = (TrieNode*)malloc(sizeof(TrieNode));
    node->isEndOfWord = false;
    int i;
    for (i = 0; i < ALPHABET_SIZE; i++) {
        node->children[i] = NULL;
    }
    return node;
}


void insertWord(TrieNode* root, const char* word) {
    int length = strlen(word);
    TrieNode* currentNode = root;
    int i;
    for (i = 0; i < length; i++) {
        char c = toupper(word[i]);
        int index;

        if (c >= 'A' && c <= 'Z') {
            if (c >= 'A' && c <= 'C') {
                index = 2;
            } else if (c >= 'D' && c <= 'F') {
                index = 3;
            } else if (c >= 'G' && c <= 'I') {
                index = 4;
            } else if (c >= 'J' && c <= 'L') {
                index = 5;
            } else if (c >= 'M' && c <= 'O') {
                index = 6;
            } else if (c >= 'P' && c <= 'S') {
                index = 7;
            } else if (c >= 'T' && c <= 'V') {
                index = 8;
            } else if (c >= 'W' && c <= 'Z') {
                index = 9;
            } else {
                printf("Ge�ersiz karakter: %c\n", word[i]);
                return;
            }
        } else {
            printf("Ge�ersiz karakter: %c\n", word[i]);
            return;
        }

        if (currentNode->children[index] == NULL) {
            currentNode->children[index] = createNode();
        }

        currentNode = currentNode->children[index];
    }

    currentNode->isEndOfWord = true;
}


void findWordsUtil(TrieNode* root, const char* number, int pos, char* result, const char** dictionary, int dictionarySize) {
    if (root == NULL) {
        return;
    }

    int j;

    if (number[pos] == '\0') {
        if (root->isEndOfWord) {
        	result[pos] = '\0';  // Result'� sonland�rma i�aretiyle bitir
            for (j = 0; j < dictionarySize; j++) {
                if (stricmp(dictionary[j], result) == 0) {
                    printf("%s\n", result);
                    break;
                }
            }
        }
        return;
    }

    int index = number[pos] - '0';
    TrieNode* currentNode = root->children[index];

    if (currentNode == NULL) {
        return;
    }

    const char* keypad[] = {
        "",      // 0
        "",      // 1
        "ABC",   // 2
        "DEF",   // 3
        "GHI",   // 4
        "JKL",   // 5
        "MNO",   // 6
        "PQRS",  // 7
        "TUV",   // 8
        "WXYZ"   // 9
    };

    const char* letters = keypad[index];
    int lettersLength = strlen(letters);

    int i;
    for (i = 0; i < lettersLength; i++) {
        result[pos] = letters[i];
        result[pos + 1] = '\0';

        findWordsUtil(currentNode, number, pos + 1, result, dictionary, dictionarySize);
    }
}


void printTrieContents(TrieNode* root, const char* number, const char** dictionary, int dictionarySize) {
    char result[MAX_NUMBER_LENGTH];
    findWordsUtil(root, number, 0, result, dictionary, dictionarySize);
}


int readDictionaryFromFile(const char* fileName, const char*** dictionary) {
    FILE* file = fopen(fileName, "r");
    if (file == NULL) {
        printf("Dosya okunamad�: %s\n", fileName);
        return 0;
    }

    const int maxWordLength = 100;
    const int initialSize = 10;
    int dictionarySize = 0;
    int dictionaryCapacity = initialSize;
    const char** tempDictionary = (const char**)malloc(initialSize * sizeof(const char*));

    char word[maxWordLength];
    while (fgets(word, maxWordLength, file) != NULL) {
        int wordLength = strlen(word);
        if (word[wordLength - 1] == '\n') {
            word[wordLength - 1] = '\0';  // Yeni sat�r karakterini sil
            wordLength--;
        }

        if (wordLength > 0) {
            if (dictionarySize == dictionaryCapacity) {
                dictionaryCapacity *= 2;
                tempDictionary = (const char**)realloc(tempDictionary, dictionaryCapacity * sizeof(const char*));
            }

            tempDictionary[dictionarySize] = strdup(word);
            dictionarySize++;
        }
    }

    fclose(file);

    *dictionary = (const char**)malloc(dictionarySize * sizeof(const char*));
    memcpy(*dictionary, tempDictionary, dictionarySize * sizeof(const char*));

    free(tempDictionary);

    return dictionarySize;
}


int main() {
	setlocale(LC_ALL, "Turkish");
    TrieNode* root = createNode();
    int i;

    const char** dictionary;
    int dictionarySize = readDictionaryFromFile("dictionary.txt", &dictionary);
    if (dictionarySize == 0) {
        return 1;
    }

    // S�zl��� trie'ye ekleme
    for (i = 0; i < dictionarySize; i++) {
        insertWord(root, dictionary[i]);
    }

    char number[MAX_NUMBER_LENGTH];
    printf("Say�y� giriniz: ");
    fgets(number, sizeof(number), stdin);
    number[strcspn(number, "\n")] = '\0';

    printf("Say�ya kar��l�k gelen kelimeler:\n");
    printTrieContents(root, number, dictionary, dictionarySize);

    // Bellekten s�zl�k dizisi i�in ayr�lan yerleri serbest b�rak�n
    for (i = 0; i < dictionarySize; i++) {
        free((char*)dictionary[i]);
    }
    free(dictionary);

    return 0;
}




